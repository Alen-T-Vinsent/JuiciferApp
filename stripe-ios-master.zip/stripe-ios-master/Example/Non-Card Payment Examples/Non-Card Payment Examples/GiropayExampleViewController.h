//
//  GiropayExampleViewControllewrViewController.h
//  Non-Card Payment Examples
//
//  Created by Cameron Sabol on 4/22/20.
//  Copyright © 2020 Stripe. All rights reserved.
//

#import "PaymentExampleViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface GiropayExampleViewController : PaymentExampleViewController

@end

NS_ASSUME_NONNULL_END
