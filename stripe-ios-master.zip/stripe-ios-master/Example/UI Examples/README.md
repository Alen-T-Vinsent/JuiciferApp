# UI Examples

This example app lets you try out the pre-built UI components we provide.

You can run it without any initial setup and it's a great place to start if you're evaluating whether you want to use our [Basic Integration](/Example/Basic%20Integration/README.md) or use the UI components individually.

1. Open `stripe-ios/Stripe.xcworkspace` (not `stripe-ios/Stripe.xcodeproj`) with Xcode
2. Build and run the "UI Examples" scheme
