//
//  StripeCore.h
//  StripeCore
//
//  Created by Mel Ludowise on 6/24/21.
//

#import <Foundation/Foundation.h>

//! Project version number for StripeCore.
FOUNDATION_EXPORT double StripeCoreVersionNumber;

//! Project version string for StripeCore.
FOUNDATION_EXPORT const unsigned char StripeCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <StripeCore/PublicHeader.h>


