//
//  STDSThreeDSProtocolVersion.h
//  Stripe3DS2
//
//  Created by Cameron Sabol on 6/27/19.
//  Copyright © 2019 Stripe. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

FOUNDATION_EXPORT NSString * const Stripe3DS2ProtocolVersion;

NS_ASSUME_NONNULL_END
